package com.lembreteappspring.lembreteappspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LembreteappspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
